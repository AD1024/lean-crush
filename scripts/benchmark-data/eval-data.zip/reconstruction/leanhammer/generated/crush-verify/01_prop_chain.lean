import Hammer

open Lean Elab Tactic

private def runBenchmarkDirect (premises : TSyntaxArray `term) : TacticM Unit :=
    withMainContext do
  let terms ← premises.mapM fun premise => do
    let proof ← Term.elabTerm premise none
    Term.synthesizeSyntheticMVarsNoPostponing
    let proof ← instantiateMVars proof
    let descr := premise.reprint.getD "benchmark hint"
    pure (proof, descr)
  let cfg := {
    Crush.Config.ofOptions (← getOptions) with
    backend := .cvc5
    timeout := 5
    trust := .trust
    reconstruct := .auto
    profile := true
    profileMachine := true
  }
  let start <- IO.monoMsNow
  try
    Crush.runCrush (← getMainGoal) cfg {
      terms
      allHyps := true
      allowPremiseSelection := false
    }
    let stop <- IO.monoMsNow
    logInfo m!"BENCHMARK_MS={stop - start}"
  catch e =>
    let stop <- IO.monoMsNow
    logInfo m!"BENCHMARK_MS={stop - start}"
    throw e

syntax "benchmark_hammer" : tactic
syntax "benchmark_hammer" "[" term,* "]" : tactic

elab_rules : tactic
  | `(tactic| benchmark_hammer) => runBenchmarkDirect #[]
  | `(tactic| benchmark_hammer [$premises,*]) =>
    runBenchmarkDirect premises


example (p q r : Prop) (hpq : p → q) (hqr : q → r) (hp : p) : r := by
  benchmark_hammer
